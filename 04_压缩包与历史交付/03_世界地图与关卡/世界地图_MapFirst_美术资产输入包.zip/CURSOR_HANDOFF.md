# Journey Map Art Asset Handoff

## Install
Copy `public/journey/` into the project's existing `public/` directory.

## Hard constraint
**所有地图、人物、宝箱、罗盘和装饰图像一律使用 `<img>` 或 SVG `<image>` 引用 `/journey/` 目录中的真实资产；禁止使用 SVG/CSS 重绘人物、建筑和世界地图。**

## Map-first rule
- `world-map.webp` is the page background, not a card image.
- Route lines, 50 level nodes, labels and chests remain interactive SVG/DOM overlays.
- Never bake numbers, region names or buttons into the map.

## Recommended DOM order
1. world map image
2. atmosphere overlay
3. SVG routes and nodes
4. region labels
5. floating profile/progress panels
6. popovers and navigation

## Nine-slice
Use `card-frame-9slice.png` with:
```css
border-image: url('/journey/card-frame-9slice.png') 30% fill / 34px / 0 stretch;
```

## Responsive assets
- Desktop: `/journey/world-map.webp`
- Mobile: `/journey/world-map-mobile.webp`

## Notes
This package is a game-test prototype art pack. Region labels and buttons are included as optional art references; for accessibility, real text should remain DOM text layered over them.
