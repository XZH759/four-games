# Cursor 游戏精美化实施包

本实施包用于把当前“初始形象创建”页面从普通网页原型升级为精致、统一、可扩展的暖暖风游戏界面。

## 最重要的原则

Cursor 擅长：
- 页面结构、组件、状态管理；
- CSS 视觉系统；
- 过渡动画和交互反馈；
- 图片图层组合与资源管理。

Cursor 不擅长凭空绘制高精度角色立绘。正式效果需要先准备统一角色素材，再交给 Cursor 集成。不要要求 Cursor 用 div、简单 SVG 或 CSS 几何图形画出最终人物。

## 推荐使用顺序

1. 把本文件夹复制到项目根目录，建议改名为 `design-kit/`。
2. 把你提供的设计模板放进 `design-kit/references/`。
3. 依次把 `prompts/01` 到 `prompts/06` 发给 Cursor，不要一次性全部发送。
4. 先让 Cursor 完成审计和架构，再放入正式人物素材。
5. 使用 `scripts/validate-avatar-assets.mjs` 检查所有透明图层尺寸是否一致。
6. 完成后按照 `checklists/visual-qa.md` 做最终验收。

## 文件说明

- `prompts/01_master_audit.md`：让 Cursor 检查现有项目并制定修改计划。
- `prompts/02_asset_architecture.md`：建立高清分层人物系统。
- `prompts/03_visual_polish.md`：实现暖暖风 UI 视觉精修。
- `prompts/04_interaction_polish.md`：实现点击、切换、预加载、过渡和反馈。
- `prompts/05_integrate_assets.md`：将正式立绘接入页面。
- `prompts/06_final_qa.md`：最终修复和验收。
- `prompts/image_generation_prompts.md`：用于生成统一角色与服装素材的提示词。
- `styles/game-theme.css`：可直接复用的颜色、边框、按钮与动效变量。
- `styles/avatar-motion.css`：角色切换、卡片选择和减弱动画支持。
- `src/avatar/avatar-manifest.ts`：人物资源配置模板。
- `src/avatar/AvatarRenderer.tsx`：React 分层渲染示例。
- `scripts/validate-avatar-assets.mjs`：检查角色资源尺寸和透明通道。
- `assets/ui/*.svg`：可直接使用的原创星光主题装饰素材。
