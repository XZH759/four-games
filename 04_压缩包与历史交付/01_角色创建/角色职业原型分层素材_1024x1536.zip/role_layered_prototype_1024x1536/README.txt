统一画布原型分层文件
Canvas: 1024x1536
Anchor: foot-center (512,1216)
Layer order: body -> outfit -> hairBack -> face -> eyes -> hairFront -> accessory

说明：
1. 当前来源为扁平化预览图中的半身角色卡，而非可编辑全身分层原画。
2. 因此本包为“原型叠戴测试包”，适合前端接入、规则验证与风格预演。
3. 若后续提供全身原画/PSD/AI，可按同一画布和层序无损重建正式素材。
