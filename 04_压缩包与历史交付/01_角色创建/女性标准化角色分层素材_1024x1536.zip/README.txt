Canvas: 1024x1536
Anchor: foot center (512,1216)
Layer order: body -> outfit -> hairBack -> face -> eyes -> hairFront -> accessory

All files are full-canvas transparent PNGs.
This is a prototype-standardized export based on reference sheets rather than source PSD layers.
