统一画布: 1024x1536
角色锚点: 脚底中心 (512,1216)
层序: body -> outfit -> hairBack -> face -> eyes -> hairFront -> accessory

输出内容: 每层 PNG + SVG。
